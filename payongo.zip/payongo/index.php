<?php
header('location: my/');
?>
